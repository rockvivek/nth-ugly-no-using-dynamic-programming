#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
    int n = 150;
    
    int ugly[n];
    ugly[0] = 1;
    
    int count = 1;
    int m2 = 2,m3= 3,m5 = 5;
    int i2=0,i3=0,i5=0;
    int next_ugly_no,i=1;
    while(count++<n){
        next_ugly_no = min(min(m2,m3),m5);
        ugly[i++] = next_ugly_no; 
        if(next_ugly_no == m2){
            i2+=1;
            m2 = ugly[i2]*2;
        }
        if(next_ugly_no == m3){
            i3+=1;
            m3 = ugly[i3]*3;
        }    
        if(next_ugly_no == m5){
            i5+=1;
            m5 = ugly[i5]*5;
        }    
    }
    cout<<ugly[i-1];
    return 0;
}

